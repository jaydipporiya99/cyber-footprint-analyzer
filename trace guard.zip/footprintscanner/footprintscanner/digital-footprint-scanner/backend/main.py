from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import os
import concurrent.futures

from backend.scanners.breach_scanner import scan_email_breaches
from backend.scanners.username_scanner import scan_username
from backend.scanners.google_scanner import search_google_leaks
from backend.scanners.phone_scanner import scan_phone
from backend.scanners.document_scanner import scan_documents
from backend.scanners.github_scanner import scan_github
from backend.scanners.social_email_scanner import scan_social_email
from backend.scanners.email_presence_scanner import scan_email_presence
from backend.osint_engine import run_osint
from backend.analyzer.risk_score import calculate_risk
from backend.analyzer.advisor import generate_advice
from backend.analyzer.behavior import analyze_behavior
from database.db import save_scan, get_history
from reports.report_generator import generate_markdown_report

app = FastAPI(title="TraceGuard", version="1.0")

# Allow requests from our frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ScanRequest(BaseModel):
    email: str = ""
    username: str = ""
    phone: str = ""
    name: str = ""

@app.post("/scan")
def run_scan(request: ScanRequest, mode: str = "quick"):
    if not request.email and not request.username and not request.phone:
        raise HTTPException(status_code=400, detail="Must provide at least email, username, or phone.")

    results = {}
    
    # Run Scanners concurrently to drastically decrease scan time
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_osint = executor.submit(run_osint, request.email, request.username, request.phone, request.name, mode)
        
        future_email_breaches = None
        future_social_email = None
        future_email_presence = None
        if request.email:
            future_email_breaches = executor.submit(scan_email_breaches, request.email)
            future_social_email = executor.submit(scan_social_email, request.email)
            future_email_presence = executor.submit(scan_email_presence, request.email)
            
        future_social_accounts = None
        future_github_exposure = None
        if request.username:
            future_social_accounts = executor.submit(scan_username, request.username)
            future_github_exposure = executor.submit(scan_github, request.username)
            
        future_phone_exposure = None
        if request.phone:
            future_phone_exposure = executor.submit(scan_phone, request.phone)
            
        query = request.name or request.username or "unknown_query"
        future_document_leaks = executor.submit(scan_documents, query)
        future_google_exposure = executor.submit(search_google_leaks, query)

        # Collect results
        results.update(future_osint.result())
        
        if request.email:
            results["email_breaches"] = future_email_breaches.result()
            results["social_email"] = future_social_email.result()
            results["email_presence"] = future_email_presence.result()
            
        if request.username:
            results["social_accounts"] = future_social_accounts.result()
            results["github_exposure"] = future_github_exposure.result()
            
        if request.phone:
            results["phone_exposure"] = future_phone_exposure.result()
            
        results["document_leaks"] = future_document_leaks.result()
        results["google_exposure"] = future_google_exposure.result()

    # Analyze Data
    risk_analysis = calculate_risk(results)
    results["risk_analysis"] = risk_analysis
    results["advice"] = generate_advice(risk_analysis)
    results["behavior"] = analyze_behavior(results)
    
    # Save to history
    save_scan(
        email=request.email,
        username=request.username,
        phone=request.phone,
        risk_score=risk_analysis["score"],
        risk_level=risk_analysis["level"],
        results=results
    )

    return results

@app.get("/history")
def history():
    return get_history()

@app.post("/report")
def get_report(request: ScanRequest):
    scan_results = run_scan(request)
    report_md = generate_markdown_report(scan_results)
    return {"report": report_md}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

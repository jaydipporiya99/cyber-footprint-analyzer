def calculate_risk(scan_results: dict):
    """
    Calculates the risk score and risk level based on scan results.
    """
    score = 0
    breakdown = {}

    # 1. Email Breaches (Max 50)
    breaches = scan_results.get("email_breaches", [])
    if breaches:
        score += 20
        breakdown["Email Breach"] = 20
        # Check for passwords specifically
        for b in breaches:
            if "Passwords" in b.get("DataClasses", []):
                score += 30
                breakdown["Password Leak"] = 30
                break

    # 2. Public Social Accounts (Max 10)
    accounts = scan_results.get("social_accounts", [])
    if len(accounts) > 0:
        score += 10
        breakdown["Public Social Accounts"] = 10

    # 3. Phone exposure
    phone_data = scan_results.get("phone_exposure", {})
    if phone_data:
        if not phone_data.get("valid", True):
            score += 5
            breakdown["Invalid Phone Format"] = 5
        elif phone_data.get("spam_risk") is True or phone_data.get("public_exposure") is True:
            score += 10
            breakdown["Phone Exposure"] = 10

    # Social Email Platforms
    social_email = scan_results.get("social_email", {})
    social_count = 0
    if social_email.get("instagram", {}).get("found") is True:
        score += 10
        breakdown["Instagram Found"] = 10
        social_count += 1
    if social_email.get("snapchat", {}).get("found") is True:
        score += 10
        breakdown["Snapchat Found"] = 10
        social_count += 1
    
    if social_count == 2:
        score += 5
        breakdown["Multiple Social Networks"] = 5

    # 3.5 Email Presence
    email_presence = scan_results.get("email_presence", {})
    if email_presence:
        services = email_presence.get("services", [])
        exposure = email_presence.get("exposure_level", "Low")
        
        if services:
            platform_score = len(services) * 5
            score += platform_score
            breakdown["Email Connected Platforms"] = platform_score
            
        if exposure == "High":
            score += 10
            breakdown["High Email Exposure"] = 10

    # 4. Document leaks (Max 15)
    docs = scan_results.get("document_leaks", [])
    if len(docs) > 0:
        score += 15
        breakdown["Document Leaks"] = 15

    # OSINT Tools Additions
    tools_used = scan_results.get("tools_used", [])
    if len(tools_used) > 2:
        score += 5
        breakdown["Deep Scanning Penalty"] = 5

    osint_leaks = scan_results.get("leaks", [])
    osint_breaches = scan_results.get("breaches", [])
    osint_github = scan_results.get("github_exposure", [])

    if len(osint_leaks) > 0:
        score += 15
        breakdown["OSINT Leaks found"] = 15
    if len(osint_breaches) > 0:
        score += 20
        breakdown["Darkweb/Breach Mentions"] = 20
    if len(osint_github) > 0:
        score += 15
        breakdown["GitHub/Dev Exposures"] = 15

    # 5. Multiple exposures bonus (Max 15)
    if len(breakdown) >= 4:
        score += 15
        breakdown["Repeated Exposure Bonus"] = 15

    # Cap score at 100
    score = min(score, 100)

    # Determine level
    level = "✅ Low"
    if score > 70:
        level = "🚨 High"
    elif score > 30:
        level = "⚠️ Medium"

    return {
        "score": score,
        "level": level,
        "breakdown": breakdown
    }

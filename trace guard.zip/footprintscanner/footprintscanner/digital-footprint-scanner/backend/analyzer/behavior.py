def analyze_behavior(scan_results: dict):
    """
    Analyzes behavioral risk patterns (e.g., username reuse across platforms).
    """
    insights = []
    accounts = scan_results.get("social_accounts", [])
    
    if len(accounts) > 3:
        insights.append(
            f"High Username Reuse: You use the same username across {len(accounts)} platforms. "
            "This makes it easier for attackers to build a profile on you."
        )
    elif len(accounts) > 0:
        insights.append("Slight Username Reuse detected.")
    else:
        insights.append("No significant username reuse detected.")
        
    return insights

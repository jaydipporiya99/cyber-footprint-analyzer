def generate_advice(risk_results: dict):
    """
    Generates personalized advice based on the risk score and identified exposures.
    """
    advice = []
    
    breakdown = risk_results.get("breakdown", {})
    score = risk_results.get("score", 0)

    if score == 0:
        advice.append("Great job! No major exposures were found. Keep up the good work and continue using strong passwords and 2FA.")
        return advice

    if "Email Breach" in breakdown:
        advice.append("Check HaveIBeenPwned for more details on your email breaches. Change passwords for any affected accounts immediately.")
        
    if "Password Leak" in breakdown:
        advice.append("CRITICAL: Your passwords have been exposed in a breach! Change your passwords immediately and use a password manager to ensure unique passwords across all sites.")

    if "Public Social Accounts" in breakdown:
        advice.append("Your social media accounts are publicly viewable. Consider tightening your privacy settings to reduce OSINT (Open Source Intelligence) risks.")

    if "Phone Exposure" in breakdown:
        advice.append("Your phone number is exposed or linked to messaging apps. Be cautious of SMiShing (SMS Phishing) attacks and unknown callers.")

    if "Document Leaks" in breakdown:
        advice.append("We found documents (like resumes or PDFs) matching your queries. Review these documents to ensure they don't contain sensitive PII (Personally Identifiable Information).")

    return advice

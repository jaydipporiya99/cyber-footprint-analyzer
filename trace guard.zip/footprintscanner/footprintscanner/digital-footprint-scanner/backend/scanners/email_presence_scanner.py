import subprocess
import json
import os
import sys

def get_holehe_path():
    return os.path.join(os.path.dirname(sys.executable), "Scripts", "holehe.exe" if os.name == 'nt' else "holehe")

def scan_email_presence(email: str):
    """
    Scans an email using holehe to detect which platforms it is registered on.
    """
    if not email:
        return {}
        
    print(f"[*] Scanning email presence for: {email}")
    try:
        # Run holehe and capture only the used platforms (increased timeout to 120s as holehe needs to finish to print results)
        holehe_exe = get_holehe_path()
        result = subprocess.run([holehe_exe, email, "--only-used", "--no-color"], capture_output=True, text=True, timeout=120)
        
        platforms = []
        if result.returncode == 0 and result.stdout:
            for line in result.stdout.split('\n'):
                line = line.strip()
                # Holehe outputs found platforms like: [+] amazon.com
                if line.startswith("[+]") and not "Email used" in line:
                    # extract the platform name
                    platform = line.replace("[+]", "").strip()
                    # Capitalize for better presentation (e.g. amazon.com -> Amazon)
                    if platform.endswith(".com") or platform.endswith(".net") or platform.endswith(".org"):
                        name = platform.rsplit(".", 1)[0].capitalize()
                    else:
                        name = platform.capitalize()
                    platforms.append(name)
                    
        # Calculate exposure level
        count = len(platforms)
        if count <= 2:
            exposure = "Low"
        elif count <= 5:
            exposure = "Medium"
        else:
            exposure = "High"
            
        return {
            "services": platforms,
            "count": count,
            "exposure_level": exposure
        }
    except Exception as e:
        print(f"Error running holehe: {e}")
        return {
            "services": [],
            "count": 0,
            "exposure_level": "Low"
        }

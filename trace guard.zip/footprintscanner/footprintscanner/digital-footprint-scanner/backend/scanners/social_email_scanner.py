import subprocess
import json
import os
import sys

def get_holehe_path():
    return os.path.join(os.path.dirname(sys.executable), "Scripts", "holehe.exe" if os.name == 'nt' else "holehe")

def run_holehe(email: str):
    """
    Runs the Holehe OSINT tool to check email associations.
    Returns standard output if successful, else None.
    """
    try:
        holehe_exe = get_holehe_path()
        result = subprocess.run([holehe_exe, email, "--only-used", "--no-color"], capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            return result.stdout.lower()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return None

def check_instagram(email: str, holehe_output: str):
    """
    Checks if email is linked to Instagram using holehe output or safe simulation.
    """
    if holehe_output is not None:
        if "instagram.com" in holehe_output or "instagram" in holehe_output:
            return {"found": True, "confidence": "high"}
        return {"found": False, "confidence": "high"}
    
    # Fallback to simulated safe result if Holehe is not installed
    # We do not attempt real logins to adhere to ethical constraints
    return {"found": "unknown", "confidence": "low", "error": "Holehe not installed"}

def check_snapchat(email: str, holehe_output: str):
    """
    Checks if email is linked to Snapchat using holehe output or safe simulation.
    """
    if holehe_output is not None:
        if "snapchat.com" in holehe_output or "snapchat" in holehe_output:
            return {"found": True, "confidence": "high"}
        return {"found": False, "confidence": "high"}
    
    # Fallback to simulated safe result if Holehe is not installed
    return {"found": "unknown", "confidence": "low", "error": "Holehe not installed"}

def scan_social_email(email: str):
    """
    Scans the email for linked social media profiles safely.
    """
    if not email:
        return {}

    print(f"[*] Scanning social media links for email: {email}")
    holehe_out = run_holehe(email)

    return {
        "instagram": check_instagram(email, holehe_out),
        "snapchat": check_snapchat(email, holehe_out)
    }

import requests

def scan_github(username: str):
    """
    Simulates GitHub scanning for exposed emails and secrets.
    """
    if not username:
        return {}

    print(f"[*] Scanning GitHub for: {username}")
    
    # Check if user exists on GitHub via API
    try:
        url = f"https://api.github.com/users/{username}"
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            data = response.json()
            return {
                "profile_found": True,
                "public_repos": data.get("public_repos", 0),
                "exposed_email": data.get("email", "Hidden"),
                "potential_secrets_leaked": data.get("public_repos", 0) > 10 # Mock logic
            }
    except Exception:
        pass
        
    return {
        "profile_found": False,
        "public_repos": 0,
        "exposed_email": None,
        "potential_secrets_leaked": False
    }

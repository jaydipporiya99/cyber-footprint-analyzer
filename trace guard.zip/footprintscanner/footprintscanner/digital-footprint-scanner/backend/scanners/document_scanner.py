def scan_documents(query: str):
    """
    Simulates finding leaked documents (resumes, public PDFs).
    """
    if not query:
        return []

    print(f"[*] Scanning document leaks for: {query}")
    docs = []
    
    if "cv" in query.lower() or "resume" in query.lower() or "test" in query.lower():
        docs.append({
            "filename": f"{query.replace(' ', '_')}_Resume_2023.pdf",
            "source": "Scribd (Mock)",
            "threat_level": "Medium"
        })
        
    return docs

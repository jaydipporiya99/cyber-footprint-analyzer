import requests
import json

def scan_email_breaches(email: str):
    """
    Scans for email breaches using the HaveIBeenPwned API (or similar).
    For demonstration without an API key, we simulate a response based on common patterns.
    """
    if not email:
        return []

    # HIBP requires an API key. 
    # Example actual implementation:
    # headers = {'hibp-api-key': 'YOUR_KEY'}
    # response = requests.get(f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}", headers=headers)
    # return response.json() if response.status_code == 200 else []

    # Simulation for beginner-friendly out-of-the-box working code:
    print(f"[*] Scanning email breaches for: {email}")
    mock_breaches = []
    
    if "test" in email.lower() or "admin" in email.lower():
        mock_breaches.extend([
            {"Name": "LinkedIn", "DataClasses": ["Email addresses", "Passwords"], "BreachDate": "2012-05-05"},
            {"Name": "Canva", "DataClasses": ["Email addresses", "Names", "Passwords"], "BreachDate": "2019-05-24"}
        ])
    elif "hacker" in email.lower():
        mock_breaches.extend([
            {"Name": "000webhost", "DataClasses": ["Email addresses", "IP addresses", "Names", "Passwords"], "BreachDate": "2015-03-01"},
            {"Name": "Adobe", "DataClasses": ["Email addresses", "Password hints", "Passwords"], "BreachDate": "2013-10-04"}
        ])
    
    # If no mock condition is met, randomly say no breach
    return mock_breaches

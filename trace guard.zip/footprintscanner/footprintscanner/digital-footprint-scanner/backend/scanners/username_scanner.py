import requests
import concurrent.futures

def check_site(username, site_name, url_format):
    """
    Checks if a username exists on a given website by checking the HTTP status code.
    """
    url = url_format.format(username)
    try:
        # User-Agent to prevent basic blocks
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code == 200:
            return {"site": site_name, "url": url, "status": "Found"}
        elif site_name == "LinkedIn" and response.status_code == 999:
            return {"site": site_name, "url": url, "status": "Likely Found (Log-in Restricted)"}
    except requests.RequestException:
        pass
    return None

def scan_username(username: str):
    """
    Sherlock-style OSINT scanner for usernames.
    Checks common social media platforms and forums.
    """
    if not username:
        return []

    print(f"[*] Scanning username presence for: {username}")
    
    # A small selection of sites for demonstration (full Sherlock has 300+)
    sites = [
        ("GitHub", "https://github.com/{}"),
        ("Twitter", "https://nitter.net/{}"), # Nitter as Twitter alternative for scraping
        ("Reddit", "https://www.reddit.com/user/{}"),
        ("Pinterest", "https://www.pinterest.com/{}/"),
        ("Vimeo", "https://vimeo.com/{}"),
        ("Patreon", "https://www.patreon.com/{}"),
        ("Pastebin", "https://pastebin.com/u/{}"),
        ("LinkedIn", "https://www.linkedin.com/in/{}/")
    ]
    
    found_accounts = []
    
    # Use multithreading to speed up the checks
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        future_to_site = {
            executor.submit(check_site, username, site_name, url_format): site_name 
            for site_name, url_format in sites
        }
        
        for future in concurrent.futures.as_completed(future_to_site):
            result = future.result()
            if result:
                found_accounts.append(result)
                
    return found_accounts

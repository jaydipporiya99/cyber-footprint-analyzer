import phonenumbers
from phonenumbers import geocoder, carrier, timezone
import random
import os
import requests

def scan_phone(phone_number: str):
    """
    Scans a phone number for intelligence using the `phonenumbers` library.
    Validates input in E.164 international format (+123456789).
    Detects country, region, and carrier.
    Simulates exposure risk.
    """
    if not phone_number:
        return {}

    print(f"[*] Scanning phone number: {phone_number}")
    
    # Ensure it starts with '+' for phonenumbers parsing, unless the user included it
    if not phone_number.startswith('+'):
        phone_number = '+' + phone_number

    try:
        # Parse the phone number
        parsed_number = phonenumbers.parse(phone_number, None)
    except phonenumbers.NumberParseException:
        return {
            "valid": False,
            "error": "Invalid phone number format"
        }

    # Validate the phone number
    is_valid = phonenumbers.is_valid_number(parsed_number)
    if not is_valid:
        return {
            "valid": False,
            "error": "Invalid phone number format"
        }

    # Extract Country/Region
    country = geocoder.description_for_number(parsed_number, "en")
    country_code = f"+{parsed_number.country_code}"
    
    # Extract Timezone
    timezones = timezone.time_zones_for_number(parsed_number)
    primary_timezone = timezones[0] if timezones else "Unknown"

    # Extract Carrier
    carrier_name = carrier.name_for_number(parsed_number, "en")
    
    # Normalize Number to standard E.164 format
    normalized_number = phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164)

    # Fallback to Numverify API if carrier is empty (common for US/CA numbers due to portability)
    if not carrier_name:
        numverify_key = os.getenv("NUMVERIFY_API_KEY")
        if numverify_key:
            try:
                # Remove '+' for Numverify API
                api_number = normalized_number.replace("+", "")
                resp = requests.get(f"http://apilayer.net/api/validate?access_key={numverify_key}&number={api_number}", timeout=5)
                if resp.status_code == 200:
                    data = resp.json()
                    carrier_name = data.get("carrier")
            except requests.RequestException:
                pass
    
    carrier_name = carrier_name or "Unknown (Often requires API Key for this region)"

    # Simulate exposure detection
    spam_risk = random.choice([True, False, False, False]) # 25% chance of being true
    public_exposure = random.choice([True, False])         # 50% chance of being true
    
    # Mock messaging apps
    messaging_apps = []
    if is_valid:
        messaging_apps.extend(["WhatsApp", "Telegram"])

    input_digits = str(parsed_number.national_number)
    
    # Adding manual spam overrides for testing purposes
    if "800" in input_digits or "888" in input_digits:
        spam_risk = True
        carrier_name = carrier_name or "Toll-Free Simulator"

    result = {
        "valid": True,
        "normalized": normalized_number,
        "country": country or "Unknown",
        "country_code": country_code,
        "timezone": primary_timezone,
        "carrier": carrier_name,
        "spam_risk": spam_risk,
        "public_exposure": public_exposure,
        "messaging_presence": messaging_apps
    }

    return result

def generate_markdown_report(scan_results: dict):
    """
    Generates a formatted markdown report of the scan results.
    """
    report = f"# 🔐 Personal Digital Footprint Scan Report\n\n"
    report += f"**Risk Score:** {scan_results['risk_analysis']['score']} / 100\n"
    report += f"**Risk Level:** {scan_results['risk_analysis']['level']}\n\n"
    
    report += "## 📊 Risk Breakdown\n"
    for factor, score in scan_results['risk_analysis']['breakdown'].items():
        report += f"- {factor}: +{score}\n"
    
    report += "\n## 💡 AI Security Advisor\n"
    for advice in scan_results['advice']:
        report += f"- {advice}\n"

    report += "\n## 🧠 Behavioral Insights\n"
    for bh in scan_results['behavior']:
        report += f"- {bh}\n"
        
    return report

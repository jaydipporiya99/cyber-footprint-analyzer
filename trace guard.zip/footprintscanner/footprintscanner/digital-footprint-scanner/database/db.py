import sqlite3
import os
import json
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "scans.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scan_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT,
            username TEXT,
            phone TEXT,
            risk_score INTEGER,
            risk_level TEXT,
            results_json TEXT,
            scan_date TEXT
        )
    ''')
    conn.commit()
    conn.close()

def save_scan(email, username, phone, risk_score, risk_level, results):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO scan_history (email, username, phone, risk_score, risk_level, results_json, scan_date)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (email, username, phone, risk_score, risk_level, json.dumps(results), datetime.now().isoformat()))
    scan_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return scan_id

def get_history():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM scan_history ORDER BY id DESC LIMIT 50')
    rows = cursor.fetchall()
    conn.close()
    
    history = []
    for row in rows:
        history.append({
            "id": row[0],
            "email": row[1],
            "username": row[2],
            "phone": row[3],
            "risk_score": row[4],
            "risk_level": row[5],
            "results": json.loads(row[6]),
            "scan_date": row[7]
        })
    return history

# Initialize on load
init_db()

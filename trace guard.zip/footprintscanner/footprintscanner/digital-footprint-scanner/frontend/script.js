let riskChartInstance = null;

document.getElementById('scanForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value.trim();
    const username = document.getElementById('username').value.trim();
    const phoneBase = document.getElementById('phone').value.trim();
    const countryCode = document.getElementById('countryCode').value;
    const name = document.getElementById('name').value.trim();
    const mode = document.getElementById('scanMode').value;
    
    // Only concatenate if the user actually typed a phone number
    const phone = phoneBase ? `${countryCode}${phoneBase}` : "";

    if (!email && !username && !phone) {
        alert("Please provide at least one input (Email, Username, or Phone)");
        return;
    }

    // UI State: Loading
    document.getElementById('dashboard').classList.add('hidden');
    document.getElementById('loading').classList.remove('hidden');

    try {
        const response = await fetch(`http://127.0.0.1:8000/scan?mode=${mode}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, username, phone, name })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            updateDashboard(data);
        } else {
            alert(data.detail || "Error starting scan.");
            document.getElementById('loading').classList.add('hidden');
        }
    } catch (err) {
        alert("Server error. Ensure the FastAPI backend is running.");
        document.getElementById('loading').classList.add('hidden');
    }
});

function updateDashboard(data) {
    document.getElementById('loading').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    
    // Risk Score
    const score = data.risk_analysis.score;
    document.getElementById('scoreValue').textContent = score;
    document.getElementById('riskLevel').textContent = data.risk_analysis.level;
    
    const bar = document.getElementById('riskBar');
    bar.style.width = `${score}%`;
    if (score < 31) bar.style.backgroundColor = 'var(--success)';
    else if (score < 71) bar.style.backgroundColor = 'var(--warning)';
    else bar.style.backgroundColor = 'var(--danger)';

    // AI Advice
    const adviceList = document.getElementById('adviceList');
    adviceList.innerHTML = '';
    data.advice.forEach(adv => {
        let li = document.createElement('li');
        li.textContent = adv;
        adviceList.appendChild(li);
    });

    // Email Breaches
    const breachList = document.getElementById('breachList');
    breachList.innerHTML = '';
    if (data.email_breaches && data.email_breaches.length > 0) {
        data.email_breaches.forEach(b => {
            let li = document.createElement('li');
            li.innerHTML = `<strong>${b.Name}</strong> (${b.BreachDate}) - Exposed: ${b.DataClasses.join(', ')}`;
            breachList.appendChild(li);
        });
    } else {
        breachList.innerHTML = "<li>No known email breaches found.</li>";
    }

    // Email Usage Detection
    const presenceRes = document.getElementById('emailPresenceResult');
    if (data.email_presence && data.email_presence.services && data.email_presence.services.length > 0) {
        let platformsHtml = data.email_presence.services.map(p => `<li>${p} <i class="fa-solid fa-check" style="color: var(--success);"></i></li>`).join('');
        let exposureIcon = data.email_presence.exposure_level === 'High' ? '<i class="fa-solid fa-triangle-exclamation" style="color: var(--danger);"></i>' : (data.email_presence.exposure_level === 'Medium' ? '<i class="fa-solid fa-circle-exclamation" style="color: var(--warning);"></i>' : '<i class="fa-solid fa-shield-halved" style="color: var(--success);"></i>');
        
        presenceRes.innerHTML = `
            <p style="margin-bottom: 5px;"><strong>Platforms Found:</strong></p>
            <ul style="list-style: none; padding-left: 0; margin-bottom: 15px;">${platformsHtml}</ul>
            <p><strong>Exposure Level:</strong></p>
            <p style="font-size: 1.1em;">${exposureIcon} ${data.email_presence.exposure_level}</p>
        `;
    } else {
        presenceRes.innerHTML = "<p>No connected accounts found or no email provided.</p>";
    }

    // Accounts
    const accountList = document.getElementById('accountList');
    accountList.innerHTML = '';
    if (data.social_accounts && data.social_accounts.length > 0) {
        data.social_accounts.forEach(a => {
            let li = document.createElement('li');
            li.innerHTML = `<a href="${a.url}" target="_blank" style="color:var(--accent)">${a.site}</a> - ${a.status}`;
            accountList.appendChild(li);
        });
    } else {
        accountList.innerHTML = "<li>No social accounts discovered.</li>";
    }

    // Documents
    const docList = document.getElementById('documentList');
    docList.innerHTML = '';
    if (data.document_leaks && data.document_leaks.length > 0) {
        data.document_leaks.forEach(d => {
            let li = document.createElement('li');
            li.innerHTML = `<strong>${d.filename}</strong> (${d.threat_level}) via ${d.source}`;
            docList.appendChild(li);
        });
    } else {
        docList.innerHTML = "<li>No documents found.</li>";
    }

    // Tools Used
    const toolsUsed = document.getElementById('toolsUsed');
    if (data.tools_used && data.tools_used.length > 0) {
        toolsUsed.textContent = data.tools_used.join(', ');
    } else {
        toolsUsed.textContent = "Basic Scanners Only";
    }

    // OSINT Deep Intel
    const osintContainer = document.getElementById('osintContainer');
    osintContainer.innerHTML = '';
    
    let hasOsint = false;
    const osintCategories = {
        'usernames_found': { title: 'Usernames Found', icon: 'fa-user-tag', color: 'var(--success)' },
        'emails_found': { title: 'Emails Found', icon: 'fa-envelope-circle-check', color: 'var(--success)' },
        'breaches': { title: 'Breaches', icon: 'fa-triangle-exclamation', color: 'var(--danger)' },
        'leaks': { title: 'Data Leaks', icon: 'fa-database', color: 'var(--warning)' },
        'github_exposure': { title: 'GitHub Exposure', icon: 'fa-github', color: 'var(--warning)' }
    };

    Object.keys(osintCategories).forEach(key => {
        if (data[key] && data[key].length > 0) {
            hasOsint = true;
            const categoryData = osintCategories[key];
            
            let groupDiv = document.createElement('div');
            groupDiv.style.background = 'rgba(0,0,0,0.2)';
            groupDiv.style.padding = '15px';
            groupDiv.style.borderRadius = '8px';
            groupDiv.style.borderLeft = `4px solid ${categoryData.color}`;

            let header = document.createElement('h4');
            header.innerHTML = `<i class="fa-brands ${categoryData.icon} fa-solid"></i> ${categoryData.title}`;
            header.style.marginBottom = '10px';
            header.style.color = categoryData.color;
            groupDiv.appendChild(header);

            let ul = document.createElement('ul');
            ul.style.listStyleType = 'none';
            ul.style.paddingLeft = '0';
            ul.style.margin = '0';

            data[key].forEach(item => {
                let li = document.createElement('li');
                li.style.marginBottom = '5px';
                li.style.fontSize = '0.95em';
                
                // Style Sherlock [+] output specifically if present
                if (item.includes('[+]')) {
                    item = item.replace('[+]', `<span style="color:var(--success);font-weight:bold;">[+]</span>`);
                }
                
                li.innerHTML = item;
                ul.appendChild(li);
            });

            groupDiv.appendChild(ul);
            osintContainer.appendChild(groupDiv);
        }
    });

    if (!hasOsint) {
        osintContainer.innerHTML = "<p>No deep OSINT findings to display.</p>";
    }

    // Phone
    const phoneRes = document.getElementById('phoneResult');
    if (data.phone_exposure) {
        if (!data.phone_exposure.valid) {
            phoneRes.innerHTML = `<p style="color:var(--danger)"><i class="fa-solid fa-triangle-exclamation"></i> Invalid phone number format</p>`;
        } else {
            phoneRes.innerHTML = `
                <p><i class="fa-solid fa-globe"></i> Country: <strong>${data.phone_exposure.country}</strong> (${data.phone_exposure.country_code})</p>
                <p><i class="fa-solid fa-satellite-dish"></i> Carrier: <strong>${data.phone_exposure.carrier}</strong></p>
                <p><i class="fa-solid fa-clock"></i> Timezone: <strong>${data.phone_exposure.timezone || 'Unknown'}</strong></p>
                <p><i class="fa-solid fa-shield-halved"></i> Spam Risk: <strong>${data.phone_exposure.spam_risk ? 'Yes <i class="fa-solid fa-triangle-exclamation" style="color: var(--danger);"></i>' : 'No <i class="fa-solid fa-check" style="color: var(--success);"></i>'}</strong></p>
                <p><i class="fa-solid fa-mobile-screen"></i> Normalized: ${data.phone_exposure.normalized}</p>
            `;
        }
    } else {
            phoneRes.innerHTML = "<p>No phone data scanned.</p>";
        }

    // Social Media (Email-Based Detection)
    const socialEmailList = document.getElementById('socialEmailList');
    socialEmailList.innerHTML = '';
    
    if (data.social_email) {
        const renderSocial = (platformName, platformData) => {
            let icon = '<i class="fa-solid fa-circle-question" style="color: var(--warning);"></i>';
            let statusText = 'Unknown';
            if (platformData.found === true) {
                icon = '<i class="fa-solid fa-check" style="color: var(--success);"></i>';
                statusText = 'Found';
            } else if (platformData.found === false) {
                icon = '<i class="fa-solid fa-xmark" style="color: var(--danger);"></i>';
                statusText = 'Not Found';
            }
            return `<li>${platformName}: ${icon} ${statusText} <span style="font-size: 0.8em; color: var(--text-muted);">(Confidence: ${platformData.confidence})</span></li>`;
        };

        if (data.social_email.instagram) {
            socialEmailList.innerHTML += renderSocial('Instagram', data.social_email.instagram);
        }
        if (data.social_email.snapchat) {
            socialEmailList.innerHTML += renderSocial('Snapchat', data.social_email.snapchat);
        }
    } else {
        socialEmailList.innerHTML = '<li>No email provided for social scanning.</li>';
    }

    // Chart
    updateChart(data.risk_analysis.breakdown);
}

function updateChart(breakdownMap) {
    const ctx = document.getElementById('riskChart').getContext('2d');
    
    if (riskChartInstance) {
        riskChartInstance.destroy();
    }

    const labels = Object.keys(breakdownMap);
    const dataVals = Object.values(breakdownMap);

    // Provide default green if score is 0
    if (labels.length === 0) {
        labels.push("Safe");
        dataVals.push(100);
    }

    riskChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: dataVals,
                backgroundColor: [
                    '#f85149', '#58a6ff', '#d29922', '#8b949e', '#555555'
                ],
                borderWidth: 0
            }]
        },
        options: {
            plugins: {
                legend: {
                    labels: { color: '#c9d1d9' }
                }
            }
        }
    });
}
